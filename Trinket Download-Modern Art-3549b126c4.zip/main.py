#!/bin/python3

from turtle import *

from random import *


def randomcolour():
  red = randint(0, 255)
  blue = randint(0, 255)
  green = randint(0, 255)
  color(red, blue, green)


def randomplace():
  penup()
  x = randint(-125, 125)
  y = randint(-125, 125)
  goto(x,y)
  pendown()
  
def randomheading():
  heading = randint(1, 360)
  setheading(heading)
  


emma = shape("turtle")



for i in range(5):
  speed(0)
  randomcolour()
  randomplace()
  randomheading()
  stamp()

clear()
setheading(0)



hideturtle()


def drawrectangle():
  randomplace()
  randomcolour()
  hideturtle()
  length = randint(10, 100)
  height = randint(10, 100)
  begin_fill()
  forward(length)
  right(90)
  forward(height)
  right(90)
  forward(length)
  right(90)
  forward(height)
  right(90)
  end_fill()
  


for i in range(5):
  speed(0)
  drawrectangle()

clear()
setheading(0)


def drawcircle():
  dot(randint(35, 75))
  randomcolour()
  randomplace()
  
for i in range(5):
  drawcircle()


clear()
setheading(0)


def drawstar():
  begin_fill()
  for side in range(5):
    left(144)
    forward(50)
    end_fill()

for i in range(10):
  drawstar()








