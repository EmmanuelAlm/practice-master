#!/bin/python3

import pygal


piechart = pygal.Pie()
piechart.title = 'Favourtie Pets'
piechart.add('Dog', 6)
piechart.add('Artic Fox', 4)
piechart.add('coyote', 3)
piechart.add('Liger', 6)
piechart.add('Lynx', 2)
piechart.add('Penguin', 5)
piechart.add('Skunk', 1)
piechart.render()

